export class Config {
  public static API_URL = 'https://api.edamam.com/api/';

  public static nutritionDetails = `${Config.API_URL}nutrition-details`;
  public static nutritionData = `${Config.API_URL}nutrition-data`;
}
